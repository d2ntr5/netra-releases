// Netra: 모니터 하나만 골라 보기 · 확대 축소 (design/mockups/clip-zoom.html 4).
// macOS 화면 공유는 모니터를 모두 이어 붙인 한 화면을 보내므로, noVNC 가 그중 고른 모니터가 있는 곳만 잘라 화면에 맞춰 보여 줌.
// 모니터 배치는 Netra 가 /netra/monitors.json 으로 줌 (포인트, 왼쪽 위 기준). 고른 값은 이 기기 브라우저에만 저장.
// noVNC 1.7.0 의 내부 함수(RFB._updateClip · _updateScale, Display 의 viewport)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";

const KEY = "netra_monitor";
let monitors = [];
let choice = load();            // 고른 모니터 이름, 없으면 전체
let patched = null;             // 손본 RFB
// 확대: 배율(1 = 맞춤)과 보는 곳 가운데(받은 화면 좌표). 기억하지 않음 — 접속할 때마다 맞춤
const ZOOMS = [1, 1.5, 2, 3, 4];
let zoom = 1;
let center = null;
let panning = false;            // ✋ 켜짐: 한 손가락으로 화면 옮기기 (trackpad.js 가 터치를 받음)

function load() { try { return localStorage.getItem(KEY); } catch { return null; } }
function save(v) { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch { /* 저장 못 해도 지금은 적용 */ } }

function chosen() { return monitors.find(m => m.name === choice) || null; }

// 받은 화면 안에서 모니터마다 차지하는 사각형. 맥이 이어 붙이는 방식 두 가지를 받은 화면 크기와 비교해 맞는 쪽을 씀:
// - 픽셀: 모니터마다 제 픽셀 크기(포인트 × 배율). 위치는 포인트 × 가장 큰 배율 (맥미니: 더미 3840×2160 | MSI 5120×1440 → 8960×2160, 2026-11-04 아이폰 화면으로 확인)
// - 포인트: 모든 모니터를 포인트 그대로 (배율이 모두 같을 때는 둘이 같음)
function rects() {
    const top = Math.max(...monitors.map(m => m.scale || 1));
    const pixel = monitors.map(m => ({ x: m.x * top, y: m.y * top, w: m.width * (m.scale || 1), h: m.height * (m.scale || 1) }));
    const point = monitors.map(m => ({ x: m.x, y: m.y, w: m.width, h: m.height }));
    return [pixel, point];
}

function region(rfb, m) {
    const d = rfb._display;
    const i = monitors.indexOf(m);
    const fit = (list) => {
        const w = Math.max(...list.map(r => r.x + r.w)), h = Math.max(...list.map(r => r.y + r.h));
        return { list, k: d.width / w, off: Math.abs(d.height - h * (d.width / w)) };
    };
    // 가로 · 세로 비율이 받은 화면과 맞는 방식 (1픽셀 넘게 어긋나면 다음 방식)
    const tries = rects().map(fit);
    const best = tries.find(t => t.off <= 2) || tries.sort((a, b) => a.off - b.off)[0];
    const r = best.list[i];
    return { x: Math.round(r.x * best.k), y: Math.round(r.y * best.k), w: Math.round(r.w * best.k), h: Math.round(r.h * best.k) };
}

// 지금 보는 바탕 영역: 고른 모니터, 없으면 받은 화면 전체
function base(rfb) {
    const d = rfb._display;
    const m = chosen();
    return m ? region(rfb, m) : { x: 0, y: 0, w: d.width, h: d.height };
}

function apply(rfb) {
    const d = rfb._display;
    if ((!chosen() && zoom === 1) || !d.width) {
        rfb._netraClip();
        rfb._netraScale();
        changed();
        return;
    }
    const b = base(rfb);
    // 확대하면 화면(아이폰) 비율대로 잘라 빈 곳 없이 채움. 맞춤(1)은 모니터 전체
    const size = rfb._screenSize();
    const fit = Math.min(size.w / b.w, size.h / b.h) * zoom;
    const w = Math.max(1, Math.round(zoom === 1 ? b.w : Math.min(b.w, size.w / fit)));
    const h = Math.max(1, Math.round(zoom === 1 ? b.h : Math.min(b.h, size.h / fit)));
    const c = center || { x: b.x + b.w / 2, y: b.y + b.h / 2 };
    const cx = Math.min(Math.max(c.x, b.x + w / 2), b.x + b.w - w / 2);
    const cy = Math.min(Math.max(c.y, b.y + h / 2), b.y + b.h - h / 2);
    center = zoom === 1 ? null : { x: cx, y: cy };
    const r = { x: Math.round(cx - w / 2), y: Math.round(cy - h / 2), w, h };
    d.clipViewport = true;
    d.viewportChangeSize(r.w, r.h);
    const vp = d._viewportLoc;
    d.viewportChangePos(r.x - vp.x, r.y - vp.y);
    d.autoscale(size.w, size.h);
    d._damage(vp.x, vp.y, vp.w, vp.h);
    d.flip();
    rfb._setClippingViewport(false);
    rfb._fixScrollbars();
    changed();
}

// MARK: trackpad.js 가 쓰는 것

/** 지금 보는 바탕 영역 (받은 화면 좌표). 연결 전이면 null */
export function viewBase() {
    const rfb = UI.rfb;
    if (!rfb || !rfb._display.width) return null;
    return base(rfb);
}

/** 확대 중 화면 옮기기: 화면에서 손가락이 움직인 만큼 (CSS 픽셀) */
export function panBy(dx, dy) {
    const rfb = UI.rfb;
    if (!rfb || zoom === 1) return;
    const d = rfb._display, vp = d._viewportLoc;
    const c = center || { x: vp.x + vp.w / 2, y: vp.y + vp.h / 2 };
    center = { x: c.x - dx / d.scale, y: c.y - dy / d.scale };
    apply(rfb);
}

/** 확대 중이면 그 점(받은 화면 좌표)이 보이도록 옮김 (트랙패드 포인터를 따라감) */
export function reveal(x, y) {
    const rfb = UI.rfb;
    if (!rfb || zoom === 1) return;
    const vp = rfb._display._viewportLoc, m = Math.min(vp.w, vp.h) * 0.08;
    let dx = 0, dy = 0;
    if (x < vp.x + m) dx = x - (vp.x + m); else if (x > vp.x + vp.w - m) dx = x - (vp.x + vp.w - m);
    if (y < vp.y + m) dy = y - (vp.y + m); else if (y > vp.y + vp.h - m) dy = y - (vp.y + vp.h - m);
    if (!dx && !dy) return;
    center = { x: vp.x + vp.w / 2 + dx, y: vp.y + vp.h / 2 + dy };
    apply(rfb);
}

/** 상하좌우 단추: 보이는 폭 · 높이의 절반씩 */
function nudge(dx, dy) {
    const rfb = UI.rfb;
    if (!rfb || zoom === 1) return;
    const vp = rfb._display._viewportLoc;
    center = { x: vp.x + vp.w / 2 + dx * vp.w / 2, y: vp.y + vp.h / 2 + dy * vp.h / 2 };
    apply(rfb);
}

export function isPanning() { return panning && zoom > 1; }

const listeners = new Set();
/** 보는 곳이 바뀌면 부름 (트랙패드 포인터 다시 그리기) */
export function onViewChange(f) { listeners.add(f); }
function changed() { for (const f of listeners) f(); }

function setZoom(z) {
    zoom = z;
    if (zoom === 1) { center = null; panning = false; }
    renderZoom();
    if (UI.rfb && UI.rfb === patched) apply(UI.rfb);
}

function step(dir) {
    const i = ZOOMS.indexOf(zoom) + dir;
    if (i >= 0 && i < ZOOMS.length) setZoom(ZOOMS[i]);
}

function patch(rfb) {
    if (!rfb || rfb === patched) return;
    patched = rfb;
    // 창 크기 · 받은 화면 크기가 바뀔 때 noVNC 가 부르는 두 함수를 가로채서, 모니터를 골랐으면 그 모니터만 맞춤
    rfb._netraClip = rfb._updateClip.bind(rfb);
    rfb._netraScale = rfb._updateScale.bind(rfb);
    rfb._updateClip = () => chosen() ? apply(rfb) : rfb._netraClip();
    rfb._updateScale = () => chosen() ? apply(rfb) : rfb._netraScale();
    rfb.addEventListener("connect", () => apply(rfb));
    if (rfb._rfbConnectionState === "connected") apply(rfb);
}

function pick(name) {
    choice = name;
    center = null;
    save(name);
    render();
    if (UI.rfb && UI.rfb === patched) apply(UI.rfb);
    close();
}

// MARK: 화면 (noVNC 제어 막대에 버튼 하나 + 패널)

let button, panel, list;

function build() {
    const settings = document.getElementById("noVNC_settings_button");
    if (!settings) return;
    button = document.createElement("input");
    button.type = "image";
    button.alt = "모니터";
    button.title = "모니터 고르기";
    button.src = "netra/monitor.svg";
    button.id = "netra_monitor_button";
    button.className = "noVNC_button";
    const wrap = document.createElement("div");
    wrap.className = "noVNC_vcenter";
    wrap.innerHTML = `<div id="netra_monitor" class="noVNC_panel">
        <div class="noVNC_heading"><img alt="" src="netra/monitor.svg"> 모니터</div>
        <ul></ul>
        <div class="netra_note">이 기기에 기억됩니다. 고른 모니터를 화면에 맞춰 보여 줍니다.</div>
    </div>`;
    settings.before(button, wrap);
    panel = wrap.querySelector("#netra_monitor");
    list = wrap.querySelector("ul");
    button.addEventListener("click", () => panel.classList.contains("noVNC_open") ? close() : open());
    // noVNC 가 다른 패널을 열 때 이 패널은 닫힘
    const closeAll = UI.closeAllPanels;
    UI.closeAllPanels = () => { closeAll(); close(); };
}

let zoomBar;

function buildZoom() {
    zoomBar = document.createElement("div");
    zoomBar.id = "netra_zoom";
    zoomBar.innerHTML = `<button type="button" data-z="out" title="축소">−</button><span class="netra_zlv"></span><button type="button" data-z="in" title="확대">+</button>`
        + `<button type="button" data-z="pan" title="화면 옮기기 (한 손가락)">✋</button><button type="button" data-z="fit" title="맞춤으로">⤢</button>`
        + `<div class="netra_pad"><button type="button" data-z="up" title="위로">↑</button><button type="button" data-z="left" title="왼쪽으로">←</button>`
        + `<button type="button" data-z="right" title="오른쪽으로">→</button><button type="button" data-z="down" title="아래로">↓</button></div>`;
    zoomBar.addEventListener("click", (e) => {
        const k = e.target.closest("button")?.dataset.z;
        if (k === "in") step(1);
        else if (k === "out") step(-1);
        else if (k === "fit") setZoom(1);
        else if (k === "pan") { panning = !panning; renderZoom(); }
        else if (k === "up") nudge(0, -1);
        else if (k === "down") nudge(0, 1);
        else if (k === "left") nudge(-1, 0);
        else if (k === "right") nudge(1, 0);
    });
    document.body.append(zoomBar);
    renderZoom();
}

function renderZoom() {
    if (!zoomBar) return;
    zoomBar.querySelector(".netra_zlv").textContent = zoom === 1 ? "맞춤" : `${Math.round(zoom * 100)}%`;
    zoomBar.classList.toggle("netra_zoomed", zoom > 1);
    zoomBar.querySelector('[data-z="pan"]').classList.toggle("netra_on", panning);
    zoomBar.querySelector('[data-z="out"]').disabled = zoom === 1;
    zoomBar.querySelector('[data-z="in"]').disabled = zoom === ZOOMS[ZOOMS.length - 1];
}

function open() {
    UI.closeAllPanels();
    UI.openControlbar();
    panel.classList.add("noVNC_open");
    button.classList.add("noVNC_selected");
}

function close() {
    panel?.classList.remove("noVNC_open");
    button?.classList.remove("noVNC_selected");
}

function item(name, title, detail) {
    const li = document.createElement("li");
    const b = document.createElement("button");
    b.type = "button";
    b.className = (name || null) === (chosen()?.name ?? null) ? "netra_on" : "";
    b.textContent = title;
    const s = document.createElement("small");
    s.textContent = detail;
    b.append(s);
    b.addEventListener("click", () => pick(name));
    li.append(b);
    return li;
}

function render() {
    if (!button) return;
    // 모니터가 하나면 고를 것이 없음
    button.classList.toggle("noVNC_hidden", monitors.length < 2);
    list.replaceChildren(
        item(null, "전체", "모든 모니터를 한 화면에"),
        ...monitors.map((m, i) => item(m.name, `${i + 1} · ${m.name}`, `${m.width}×${m.height}${m.main ? " · 주 모니터" : ""}`)),
    );
}

async function refresh() {
    try {
        const r = await fetch("netra/monitors.json", { cache: "no-store" });
        monitors = r.ok ? await r.json() : [];
    } catch { monitors = []; }
    render();
    if (UI.rfb && UI.rfb === patched) apply(UI.rfb);
}

build();
buildZoom();
refresh();
// 다시 연결하면 noVNC 가 RFB 를 새로 만듦 → 새 것도 손봄. 모니터 배치는 다시 연결할 때 새로 받음
setInterval(() => {
    if (UI.rfb && UI.rfb !== patched) { zoom = 1; center = null; panning = false; renderZoom(); patch(UI.rfb); refresh(); }
}, 300);
