// Netra: 클립보드 패널의 「맥에 붙여넣기」 · 「맥 클립보드 가져오기」 (design/Web2.html 3A) + 맥 ⌘ · ⌥ 키 재기.
// noVNC 는 VNC 클립보드 메시지(Latin-1)로 보내 한글이 「?」가 되므로, 원격 화면 WebSocket 의 text 프레임으로
// Netra 앱에 보내고 Netra 가 맥 클립보드를 직접 다룸 (Sources/NetraCore/Control.swift). 맥에 로그인한 연결에서만 받음.
// 맥 화면 공유가 어느 VNC 키를 ⌘ 으로 받는지는 자료마다 달라서, 접속하면 후보 키를 하나씩 누른 채 Netra 에
// 「지금 맥이 누르고 있다고 보는 보조 키」를 물어 맞는 키를 고름 (calibrate).
// noVNC 1.7.0 의 내부(rfb._sock._websocket · RFB.messages.keyEvent · UI.clipboardSend)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";
import RFB from "../core/rfb.js";
import KeyTable from "../core/input/keysym.js";
import keysyms from "../core/input/keysymdef.js";
import { setMacModifiers } from "./brand.js";

let text, toast;
const waiting = [];          // 답을 기다리는 요청 [{ kind, resolve }]

function socket() {
    const r = UI.rfb;
    const ws = r && r._rfbConnectionState === "connected" ? r._sock?._websocket : null;
    if (!ws) return null;
    if (!ws._netra) {
        // Netra 의 답(text 프레임)은 noVNC 로 넘기지 않음 (noVNC 는 binary 만 읽음)
        const orig = ws.onmessage;
        ws.onmessage = (e) => typeof e.data === "string" ? answer(e.data) : orig.call(ws, e);
        ws._netra = true;
    }
    return ws;
}

/** Netra 에 묻고 답을 기다림 (3초 넘으면 null) */
function ask(message, kind) {
    const ws = socket();
    if (!ws) return Promise.resolve(null);
    return new Promise((resolve) => {
        const w = { kind, resolve };
        waiting.push(w);
        ws.send(JSON.stringify(message));
        setTimeout(() => { const i = waiting.indexOf(w); if (i >= 0) { waiting.splice(i, 1); resolve(null); } }, 3000);
    });
}

function answer(data) {
    let m;
    try { m = JSON.parse(data); } catch { return; }
    const i = m.netra === "error" ? 0 : waiting.findIndex(w => w.kind === m.netra);
    if (i < 0 || i >= waiting.length) return;
    waiting.splice(i, 1)[0].resolve(m);
}

// MARK: ⌘ · ⌥ 재기

const CANDIDATES = [["Alt_L", KeyTable.XK_Alt_L], ["Super_L", KeyTable.XK_Super_L], ["Meta_L", KeyTable.XK_Meta_L]];
let measured = null;         // 잰 RFB
let measuring = null;        // 재는 중인 Promise
let commandKey = null;       // 맥이 ⌘ 으로 받은 키 (못 찾으면 null)

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function calibrate() {
    const r = UI.rfb;
    if (!r || r._rfbConnectionState !== "connected" || r._viewOnly) return Promise.resolve(false);
    if (measured === r) return measuring;
    measured = r;
    measuring = (async () => {
        const seen = {};
        for (const [name, key] of CANDIDATES) {
            // noVNC 의 sendKey 를 거치지 않고(이름 바꾸기 없이) 그 키 그대로
            RFB.messages.keyEvent(r._sock, key, 1);
            const m = await ask({ netra: "flags", probe: name }, "flags");
            RFB.messages.keyEvent(r._sock, key, 0);
            await sleep(80);
            seen[name] = m?.flags ? m.flags.split(",") : [];
        }
        const pick = (flag) => CANDIDATES.find(([n]) => seen[n].includes(flag))?.[1] ?? null;
        commandKey = pick("command");
        setMacModifiers(commandKey, pick("option"));
        await ask({ netra: "flags", probe: "결과 " + JSON.stringify(seen) }, "flags");
        return commandKey !== null;
    })();
    return measuring;
}

// MARK: 붙여넣기 · 가져오기

/** ⌘V 를 못 보낼 때: 글자를 하나씩 쳐 넣음 (영문 · 숫자 · 기호는 확실, 한글은 맥이 받지 않을 수 있음) */
function typeText(value) {
    const r = UI.rfb;
    for (const ch of value) {
        const cp = ch.codePointAt(0);
        const key = ch === "\n" ? KeyTable.XK_Return : ch === "\t" ? KeyTable.XK_Tab : keysyms.lookup(cp);
        if (key) r.sendKey(key, "");
    }
}

async function paste() {
    if (!text.value) { show("칸에 붙여넣을 글을 넣으세요"); return; }
    if (!socket()) { show("연결된 뒤에 쓸 수 있습니다"); return; }
    const canCommand = await calibrate();
    const m = await ask({ netra: "paste", text: text.value }, "pasted");
    if (!m) { show("Netra 가 답하지 않습니다"); return; }
    if (m.netra === "error") { show(m.message || "하지 못했습니다", 5000); return; }
    const r = UI.rfb;
    if (canCommand) {
        // 맥 클립보드에 들어갔으니 ⌘V (Super 를 brand.js 가 잰 ⌘ 키로 바꿈)
        r.sendKey(KeyTable.XK_Super_L, "MetaLeft", true);
        r.sendKey(KeyTable.XK_v, "KeyV");
        r.sendKey(KeyTable.XK_Super_L, "MetaLeft", false);
        show("맥에 붙여넣었습니다");
    } else {
        typeText(text.value);
        show("맥이 ⌘ 키를 받지 않아 글자를 하나씩 쳐 넣었습니다 (맥 클립보드에도 있음)", 4000);
    }
}

async function copy() {
    if (!socket()) { show("연결된 뒤에 쓸 수 있습니다"); return; }
    const m = await ask({ netra: "copy" }, "clipboard");
    if (!m) { show("Netra 가 답하지 않습니다"); return; }
    if (m.netra === "error") { show(m.message || "하지 못했습니다", 5000); return; }
    text.value = m.text ?? "";
    show("맥 클립보드를 가져왔습니다");
}

let toastTimer = null;
function show(message, ms = 2000) {
    toast.textContent = message;
    toast.classList.add("netra_show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("netra_show"), ms);
}

function build() {
    const panel = document.getElementById("noVNC_clipboard");
    text = document.getElementById("noVNC_clipboard_text");
    if (!panel || !text) return;
    // noVNC 의 Latin-1 보내기는 끔 (한글이 「?」로 맥 클립보드를 덮음). 맥 → 아이폰(noVNC 가 받은 글)은 그대로
    text.removeEventListener("change", UI.clipboardSend);
    const row = document.createElement("div");
    row.className = "netra_clip";
    row.innerHTML = `<button type="button" class="netra_pri" data-c="paste">맥에 붙여넣기</button><button type="button" data-c="copy">맥 클립보드 가져오기</button>`;
    row.addEventListener("click", (e) => {
        const k = e.target.closest("button")?.dataset.c;
        if (k === "paste") paste();
        else if (k === "copy") copy();
    });
    const hint = document.createElement("p");
    hint.className = "netra_clip_hint";
    hint.textContent = "「맥에 붙여넣기」: 맥 클립보드에 넣고 ⌘V까지 누름(한글 됨). 「가져오기」: 맥에서 ⌘C 한 글을 이 칸으로.";
    text.after(row, hint);
    toast = document.createElement("div");
    toast.id = "netra_toast";
    document.body.append(toast);
}

build();
// 접속하면 한 번 ⌘ · ⌥ 를 잼 (보조 키 ⌘ · ⌥ 단추 · ⌘Q 도 이 결과를 씀)
setInterval(() => {
    const r = UI.rfb;
    if (r && r !== measured && r._rfbConnectionState === "connected" && (r._fbWidth || r._display?.width)) setTimeout(calibrate, 1000);
}, 500);
