// Netra: 트랙패드 모드 (아이폰 화면을 맥북 트랙패드처럼).
// 맥 화면 공유는 아이폰에 커서 모양을 보내지 않으므로 Netra 가 화살표를 직접 그림 (포인터 자리는 Netra 가 정하니 늘 앎).
// - 한 손가락 문지르기: 포인터 이동 (천천히 움직이면 더 촘촘히)   - 짧게 탭: 포인터 자리 클릭
// - 길게 누른 뒤 움직이기: 끌기 (손 떼면 놓음)                     - 두 손가락 탭: 우클릭 · 두 손가락 끌기: 스크롤
// - 확대 막대 ✋ 켜짐: 한 손가락으로 화면 옮기기 (직접 누르기 모드에서도)
// noVNC 1.7.0 의 내부(RFB.messages.pointerEvent · rfb._display · rfb._cursor)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";
import RFB from "../core/rfb.js";
import { viewBase, reveal, isPanning, panBy, onViewChange } from "./monitor.js";

const MODE_KEY = "netra_touch";
const TAP_MS = 250, TAP_MOVE = 10, HOLD_MS = 450, SCROLL_STEP = 50;
// 포인터 높이 (설정 › 점 크기를 따름)
const ARROW = { small: 18, medium: 26, large: 36 };

function get(k) { try { return localStorage.getItem(k); } catch { return null; } }
function put(k, v) { try { localStorage.setItem(k, v); } catch { /* 저장 못 해도 지금은 적용 */ } }

/** "trackpad" (기본) · "direct" (누른 자리 클릭, noVNC 그대로) */
export function touchMode() { return get(MODE_KEY) === "direct" ? "direct" : "trackpad"; }
export function setTouchMode(v) { put(MODE_KEY, v); pos = null; draw(); }

let pos = null;          // 포인터 자리 (받은 화면 좌표)
let mask = 0;            // 누른 단추 (1 왼쪽 · 4 오른쪽)
let touch = null;        // 지금 터치 하나의 상태

function rfb() {
    const r = UI.rfb;
    return r && r._rfbConnectionState === "connected" ? r : null;
}

function send(x, y, m) {
    const r = rfb();
    if (!r || r._viewOnly) return;
    RFB.messages.pointerEvent(r._sock, Math.round(x), Math.round(y), m);
}

function clampToView(p) {
    const b = viewBase();
    if (!b) return p;
    return { x: Math.min(Math.max(p.x, b.x), b.x + b.w - 1), y: Math.min(Math.max(p.y, b.y), b.y + b.h - 1) };
}

function ensurePos() {
    const b = viewBase();
    if (!b) return null;
    if (!pos || pos.x < b.x || pos.y < b.y || pos.x >= b.x + b.w || pos.y >= b.y + b.h) pos = { x: b.x + b.w / 2, y: b.y + b.h / 2 };
    return pos;
}

function moveBy(dx, dy) {
    const r = rfb();
    if (!r || !ensurePos()) return;
    const scale = r._display.scale || 1;
    // 빠르게 움직이면 멀리, 천천히 움직이면 촘촘히 (맥 트랙패드 가속처럼)
    const speed = Math.hypot(dx, dy);
    const k = speed < 2 ? 0.45 : speed < 6 ? 0.9 : speed < 14 ? 1.4 : 2;
    pos = clampToView({ x: pos.x + dx * k / scale, y: pos.y + dy * k / scale });
    send(pos.x, pos.y, mask);
    reveal(pos.x, pos.y);
    draw();
}

function click(button) {
    if (!ensurePos()) return;
    send(pos.x, pos.y, mask | button);
    send(pos.x, pos.y, mask);
    flash();
    // 키 입력이 원격 화면으로 가게 (noVNC 가 화면을 누를 때처럼). 화면 키보드가 열려 있으면 그대로 둠
    if (!document.getElementById("noVNC_keyboard_button")?.classList.contains("noVNC_selected")) UI.rfb?.focus();
}

function scroll(button) {
    if (!ensurePos()) return;
    send(pos.x, pos.y, button);
    send(pos.x, pos.y, 0);
}

// MARK: 터치

// 원격 화면 칸 전체(캔버스 둘레의 검은 바탕 포함). 트랙패드는 어디를 문질러도 됨
function onScreen(e) {
    const r = UI.rfb;
    if (!r || !r._canvas) return false;
    return touchMode() === "trackpad" ? !!r._screen?.contains(e.target) : e.target === r._canvas;
}

function handles() { return rfb() && (touchMode() === "trackpad" || isPanning()); }

function center(list) {
    let x = 0, y = 0;
    for (const t of list) { x += t.clientX; y += t.clientY; }
    return { x: x / list.length, y: y / list.length };
}

function start(e) {
    // 원격 화면에서 시작한 터치면, 다음 손가락은 화면 밖(바탕)에 닿아도 받음
    if (!touch && (!onScreen(e) || !handles())) return;
    e.preventDefault();
    e.stopPropagation();
    const c = center(e.touches);
    if (!touch) {
        touch = { at: Date.now(), last: c, moved: 0, fingers: e.touches.length, scrollX: 0, scrollY: 0, hold: null, dragging: false, pan: isPanning() };
        if (!touch.pan && touchMode() === "trackpad") {
            touch.hold = setTimeout(() => {
                // 길게 누름 → 끌기 시작
                if (!touch || touch.fingers !== 1 || touch.moved > TAP_MOVE || !ensurePos()) return;
                touch.dragging = true;
                mask = 1;
                send(pos.x, pos.y, mask);
                draw();
            }, HOLD_MS);
        }
    } else {
        touch.fingers = Math.max(touch.fingers, e.touches.length);
        touch.last = c;
    }
}

function move(e) {
    if (!touch) return;
    e.preventDefault();
    e.stopPropagation();
    const c = center(e.touches);
    const dx = c.x - touch.last.x, dy = c.y - touch.last.y;
    touch.last = c;
    touch.moved += Math.hypot(dx, dy);
    if (touch.moved > TAP_MOVE && touch.hold && !touch.dragging) { clearTimeout(touch.hold); touch.hold = null; }
    if (touch.pan) { panBy(dx, dy); return; }
    if (e.touches.length >= 2) {
        // 두 손가락 끌기 → 스크롤 (noVNC 와 같은 방향 · 단위)
        touch.scrollY += dy;
        touch.scrollX += dx;
        while (touch.scrollY > SCROLL_STEP) { scroll(0x8); touch.scrollY -= SCROLL_STEP; }
        while (touch.scrollY < -SCROLL_STEP) { scroll(0x10); touch.scrollY += SCROLL_STEP; }
        while (touch.scrollX > SCROLL_STEP) { scroll(0x20); touch.scrollX -= SCROLL_STEP; }
        while (touch.scrollX < -SCROLL_STEP) { scroll(0x40); touch.scrollX += SCROLL_STEP; }
        return;
    }
    if (touch.fingers === 1) moveBy(dx, dy);
}

function end(e) {
    if (!touch) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.touches.length > 0) { touch.last = center(e.touches); return; }
    const t = touch;
    touch = null;
    clearTimeout(t.hold);
    if (t.dragging) {
        mask = 0;
        if (pos) send(pos.x, pos.y, 0);
        draw();
        return;
    }
    if (t.pan) return;
    const quick = Date.now() - t.at < TAP_MS && t.moved < TAP_MOVE;
    if (quick && t.fingers === 1) click(1);
    else if (quick && t.fingers === 2) click(4);
}

// 캡처 단계에서 먼저 받아 noVNC(캔버스의 터치 처리)로 가지 않게 함. 마우스 · 펜은 그대로 noVNC
for (const [type, f] of [["touchstart", start], ["touchmove", move], ["touchend", end], ["touchcancel", end]]) {
    window.addEventListener(type, f, { capture: true, passive: false });
}

// MARK: 포인터 그리기

const arrow = document.createElement("div");
arrow.id = "netra_pointer";
arrow.innerHTML = `<svg viewBox="0 0 18 26" width="100%" height="100%"><path d="M1.5 1.5v20.5l5.2-5 3.4 7.6 3.3-1.5-3.4-7.4h7.1z" fill="#000" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>`;
document.body.append(arrow);

let flashTimer = null;
function flash() {
    arrow.classList.add("netra_click");
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => arrow.classList.remove("netra_click"), 160);
}

function draw() {
    const r = rfb();
    const show = r && touchMode() === "trackpad" && ensurePos();
    // noVNC 점 커서는 트랙패드 모드에서 숨김 (누른 자리에 남아 헷갈림)
    if (r?._cursor?._canvas) r._cursor._canvas.style.visibility = show ? "hidden" : "";
    if (!show) { arrow.style.display = "none"; return; }
    const d = r._display, vp = d._viewportLoc, box = r._canvas.getBoundingClientRect();
    const x = box.left + (pos.x - vp.x) * d.scale, y = box.top + (pos.y - vp.y) * d.scale;
    const inside = x >= box.left && x <= box.right && y >= box.top && y <= box.bottom;
    const h = ARROW[get("netra_dot")] || ARROW.medium;
    arrow.style.display = inside ? "block" : "none";
    arrow.style.height = `${h}px`;
    arrow.style.width = `${Math.round(h * 18 / 26)}px`;
    arrow.style.transform = `translate(${x}px, ${y}px)`;
    arrow.classList.toggle("netra_drag", mask !== 0);
}

onViewChange(draw);
window.addEventListener("resize", draw);
// 연결 · 끊김 · 다시 연결을 따라감
setInterval(draw, 300);
