// Netra: noVNC 화면을 Netra 로 (design/Web.html). noVNC 파일은 고치지 않고 이 스크립트가 바꿈.
// - 글: 아이폰 언어와 상관없이 Netra 한국어 사전 (noVNC l10n 사전을 바꿔 끼움)
// - 로그인: noVNC 「Connect」 단추 + 「Credentials」 창 대신 한 화면. 화면 공유가 묻자마자 넣은 값을 보냄
// - 끊김: 이유와 「다시 로그인」. 왼쪽 막대 Netra 로고 · 맥 보조 키 ⌃ ⌥ ⌘. 설정은 자주 쓰는 5가지 + 고급
// noVNC 1.7.0 의 UI 함수(UI.credentials · showStatus · closeAllPanels, l10n._dictionary)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";
import { l10n } from "../app/localization.js";
import RFB from "../core/rfb.js";
import KeyTable from "../core/input/keysym.js";
import { touchMode, setTouchMode } from "./trackpad.js";

let host = location.hostname.split(".")[0] || "Mac";
let version = "";

// MARK: 글 (noVNC 원문 → Netra 한국어)

function dictionary() {
    return {
        // 연결 상태
        "Connecting...": `${host}에 연결하는 중…`,
        "Disconnecting...": "연결을 끊는 중…",
        "Reconnecting...": `${host}에 다시 연결하는 중…`,
        "Internal error": "내부 오류",
        "Must set host": "주소가 없습니다",
        "Failed to connect to server": "맥에 연결하지 못했습니다",
        "Failed to connect to server: ": "맥에 연결하지 못했습니다: ",
        "Something went wrong, connection is closed": "연결이 갑자기 끊겼습니다",
        "Disconnected": "연결을 끊었습니다",
        "New connection has been rejected with reason: ": "맥이 연결을 거절했습니다: ",
        "New connection has been rejected": "사용자 이름 또는 암호가 틀렸거나, 맥이 연결을 거절했습니다",
        "Credentials are required": "맥 사용자 이름과 암호가 필요합니다",
        "Password is required": "암호가 필요합니다",
        "Are you sure you want to disconnect the session?": "원격 화면 연결을 끊을까요?",
        "Running without HTTPS is not recommended, crashes or other issues are likely.": "HTTPS 가 아닌 주소입니다. Tailscale 주소(https://…ts.net)로 여세요.",
        "noVNC encountered an error:": "화면을 여는 중 오류가 났습니다:",
        "Cancel": "취소",
        // 왼쪽 막대
        "Hide/Show the control bar": "막대 숨기기 · 보이기",
        "Drag": "끌기",
        "Move/Drag viewport": "화면 끌어서 옮기기",
        "Keyboard": "키보드",
        "Show keyboard": "키보드 보이기",
        "Extra keys": "보조 키",
        "Show extra keys": "보조 키 (⌃ ⌥ ⌘ tab esc ← ↑ → ↓ ⌃↑ ⌘Q)",
        "Ctrl": "⌃",
        "Toggle Ctrl": "⌃ control 누르고 있기",
        "Alt": "⌥",
        "Toggle Alt": "⌥ option 누르고 있기",
        "Windows": "⌘",
        "Toggle Windows": "⌘ command 누르고 있기",
        "Tab": "tab",
        "Send Tab": "tab 보내기",
        "Esc": "esc",
        "Send Escape": "esc 보내기",
        "Clipboard": "클립보드",
        "Edit clipboard content in the textarea below.": "아이폰에서 복사한 글을 아래 칸에 붙여 넣으세요.",
        "Full screen": "전체 화면",
        "Fullscreen": "전체 화면",
        "Settings": "설정",
        "Disconnect": "끊기",
        // 설정
        "Shared mode": "공유 모드 (다른 기기와 같이 보기)",
        "View only": "보기만 (조작 안 함)",
        "Clip to window": "창 크기로 자르기",
        "Scaling mode:": "크기 조정 방식:",
        "None": "실제 크기",
        "Local scaling": "화면에 맞춤",
        "Remote resizing": "맥 해상도 바꾸기",
        "Advanced": "고급",
        "Quality:": "화질 (0–9):",
        "Compression level:": "압축 (0–9):",
        "Repeater ID:": "Repeater ID:",
        "WebSocket": "WebSocket",
        "Encrypt": "암호화",
        "Host:": "주소:",
        "Port:": "포트:",
        "Path:": "경로:",
        "Automatic reconnect": "끊기면 다시 연결",
        "Reconnect delay (ms):": "다시 연결 간격 (ms):",
        "Show dot when no cursor": "커서 없을 때 점 표시",
        "Logging:": "기록:",
        "Version:": "noVNC 버전:",
        // noVNC 로그인 창 (Netra 로그인이 대신하지만 혹시 보일 때)
        "Credentials": "맥 계정",
        "Username:": "사용자 이름:",
        "Password:": "암호:",
        "Send credentials": "로그인",
        "Connect": "연결",
        "Server identity": "서버 확인",
        "Approve": "허용",
        "Reject": "거절",
    };
}

// noVNC 가 사전을 읽은 뒤(UI.start → l10n.setup) Netra 사전으로 바꿔 끼움. 이미 읽었으면 바로 바꿈
const setup = l10n.setup.bind(l10n);
l10n.setup = async (...args) => {
    try { await setup(...args); } catch { /* noVNC 사전이 없어도 Netra 사전으로 */ }
    l10n.language = "ko";
    l10n._dictionary = dictionary();
};
if (l10n._dictionary !== undefined) l10n._dictionary = dictionary();

// 탭 이름: 「juho-macmini - noVNC」 → 「juho-macmini — Netra」
function fixTitle() {
    const t = document.title;
    const want = t === "noVNC" || t === "" ? `${host} — Netra` : t.replace(/ - noVNC$/, " — Netra");
    if (want !== t) document.title = want;
}

// MARK: 로그인 · 끊김 (design/Web.html 1A · 1C)

const USER_KEY = "netra_username", REMEMBER_KEY = "netra_remember";
let pending = null;     // 로그인에 넣은 값 (메모리에만, 페이지를 닫으면 사라짐. 끊겨서 다시 연결할 때 씀)
let tried = false;      // 이 페이지에서 로그인을 눌렀는지
let lastProblem = "";   // 끊기기 전 마지막 오류 글
let rejected = false;   // 로그인 실패 (뒤따르는 「연결하지 못했습니다」로 이유를 덮지 않게)
let wasConnected = false;

function get(key) { try { return localStorage.getItem(key); } catch { return null; } }
function put(key, value) { try { value === null ? localStorage.removeItem(key) : localStorage.setItem(key, value); } catch { /* 이 기기에 저장 못 함 */ } }

let login;

function buildLogin() {
    login = document.createElement("div");
    login.id = "netra_login";
    login.dataset.mode = "login";
    login.setAttribute("translate", "no");
    login.innerHTML = `<div class="netra_wrap">
        <img class="netra_icon" src="netra/icon-192.png" alt="">
        <div class="netra_brand">Netra</div>
        <div class="netra_host"></div>
        <form class="netra_form" autocomplete="on">
            <div class="netra_t">이 맥의 사용자 이름과 암호</div>
            <label class="netra_l" for="netra_user">사용자 이름</label>
            <input id="netra_user" name="username" type="text" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" required>
            <label class="netra_l" for="netra_pass">암호</label>
            <input id="netra_pass" name="password" type="password" autocomplete="current-password" required>
            <label class="netra_chk"><input id="netra_remember" type="checkbox"> 사용자 이름 기억</label>
            <button class="netra_go" type="submit">로그인</button>
            <div class="netra_fine">암호는 Netra에 저장되지 않고 맥 화면 공유로 바로 갑니다. Safari 암호 자동 채우기를 쓸 수 있습니다.</div>
        </form>
        <div class="netra_gone">
            <div class="netra_title">연결이 끊겼습니다</div>
            <div class="netra_why"></div>
            <button class="netra_again" type="button">다시 로그인</button>
        </div>
        <div class="netra_foot"></div>
    </div>`;
    document.body.append(login);
    login.querySelector(".netra_host").textContent = host;
    login.querySelector(".netra_foot").textContent = version ? `Netra ${version}` : "Netra";
    const remember = get(REMEMBER_KEY) !== "0";
    login.querySelector("#netra_user").value = (remember && get(USER_KEY)) || "";
    login.querySelector("#netra_remember").checked = remember;
    login.querySelector("form").addEventListener("submit", (e) => {
        e.preventDefault();
        const username = login.querySelector("#netra_user").value.trim();
        const password = login.querySelector("#netra_pass").value;
        if (!username || !password) return;
        const remember = login.querySelector("#netra_remember").checked;
        put(REMEMBER_KEY, remember ? null : "0");
        put(USER_KEY, remember ? username : null);
        pending = { username, password };
        login.querySelector("#netra_pass").value = "";
        tried = true;
        rejected = false;
        lastProblem = "";
        UI.connect();
    });
    login.querySelector(".netra_again").addEventListener("click", () => showMode("login"));
}

function showMode(mode) {
    login.dataset.mode = mode;
    if (mode === "login") {
        const user = login.querySelector("#netra_user");
        setTimeout(() => (user.value ? login.querySelector("#netra_pass") : user).focus(), 50);
    }
}

// noVNC 가 연결 창을 열 때(처음 · 끊긴 뒤) Netra 로그인을 보임
function syncLogin() {
    const open = document.getElementById("noVNC_connect_dlg")?.classList.contains("noVNC_open");
    const was = login.classList.contains("netra_show");
    login.classList.toggle("netra_show", !!open);
    if (open && !was) {
        if (tried && (wasConnected || lastProblem)) {
            // 직접 끊었으면 「연결을 끊었습니다」만, 문제로 끊겼으면 이유도
            login.querySelector(".netra_title").textContent = lastProblem ? "연결이 끊겼습니다" : l10n.get("Disconnected");
            login.querySelector(".netra_why").textContent = lastProblem;
            showMode("gone");
        } else {
            showMode("login");
        }
        wasConnected = false;
    }
}

// 화면 공유가 사용자 이름 · 암호를 물으면 로그인에 넣은 값을 바로 보냄 (없으면 noVNC 창)
const askCredentials = UI.credentials;
UI.credentials = (e) => {
    if (pending && UI.rfb) {
        UI.rfb.sendCredentials({ username: pending.username, password: pending.password, target: undefined });
        return;
    }
    askCredentials(e);
};

const showStatus = UI.showStatus;
UI.showStatus = (text, type, time) => {
    if (tried && type === "error" && !rejected) lastProblem = text;
    showStatus(text, type, time);
};

// 로그인 실패(암호 틀림 · 거절)면 넣은 암호를 버리고 다시 연결하지 않음 — 틀린 암호로 되풀이해 계정이 잠기지 않게
const securityFailed = UI.securityFailed;
UI.securityFailed = (e) => {
    pending = null;
    UI.inhibitReconnect = true;
    securityFailed(e);
    const why = e.detail && "reason" in e.detail ? ` (${e.detail.reason})` : "";
    lastProblem = `사용자 이름 또는 암호가 틀렸거나, 맥이 연결을 거절했습니다${why}`;
    rejected = true;
};

function watchState() {
    const root = document.documentElement;
    if (root.classList.contains("noVNC_connected")) {
        wasConnected = true;
        lastProblem = "";
    }
}

// MARK: 왼쪽 막대 · 설정 (design/Web.html 2A · 2B)

function buildBar() {
    const logo = document.querySelector("#noVNC_control_bar .noVNC_logo");
    if (logo) {
        logo.classList.add("netra_logo");
        logo.setAttribute("translate", "no");
        logo.innerHTML = `<img src="netra/icon-192.png" alt=""><span>Netra</span>`;
    }
    const keys = { noVNC_toggle_ctrl_button: "ctrl", noVNC_toggle_alt_button: "option", noVNC_toggle_windows_button: "command" };
    for (const [id, name] of Object.entries(keys)) {
        const b = document.getElementById(id);
        if (b) b.src = `netra/key-${name}.svg`;
    }
    // 방향키 ← ↑ → ↓ (esc 다음). ⌃ ⌥ ⌘ 를 켜 둔 채 누르면 함께 보냄
    const esc = document.getElementById("noVNC_send_esc_button");
    if (esc && !document.getElementById("netra_key_left")) {
        const arrows = [["left", "왼쪽", KeyTable.XK_Left, "ArrowLeft"], ["up", "위", KeyTable.XK_Up, "ArrowUp"],
                        ["right", "오른쪽", KeyTable.XK_Right, "ArrowRight"], ["down", "아래", KeyTable.XK_Down, "ArrowDown"]];
        let after = esc;
        for (const [name, title, keysym, code] of arrows) {
            const b = document.createElement("input");
            b.type = "image";
            b.id = `netra_key_${name}`;
            b.className = "noVNC_button";
            b.src = `netra/key-${name}.svg`;
            b.alt = b.title = `${title} 방향키`;
            b.addEventListener("click", () => UI.sendKey(keysym, code));
            after.after(b);
            after = b;
        }
        // ⌃↑ (Mission Control): control + 위쪽 방향키를 한 번에
        const mc = document.createElement("input");
        mc.type = "image";
        mc.id = "netra_key_mission";
        mc.className = "noVNC_button";
        mc.src = "netra/key-mission.svg";
        mc.alt = mc.title = "⌃↑ Mission Control";
        mc.addEventListener("click", () => {
            UI.sendKey(KeyTable.XK_Control_L, "ControlLeft", true);
            UI.sendKey(KeyTable.XK_Up, "ArrowUp");
            UI.sendKey(KeyTable.XK_Control_L, "ControlLeft", false);
        });
        after.after(mc);
        // ⌘Q (앱 닫기): command + q 를 한 번에
        const quit = document.createElement("input");
        quit.type = "image";
        quit.id = "netra_key_quit";
        quit.className = "noVNC_button";
        quit.src = "netra/key-quit.svg";
        quit.alt = quit.title = "⌘Q 앱 닫기";
        quit.addEventListener("click", () => {
            UI.sendKey(KeyTable.XK_Super_L, "MetaLeft", true);
            UI.sendKey(KeyTable.XK_q, "KeyQ");
            UI.sendKey(KeyTable.XK_Super_L, "MetaLeft", false);
        });
        mc.after(quit);
    }
}

function seg(options, current, onPick) {
    const box = document.createElement("span");
    box.className = "netra_seg";
    for (const [value, title] of options) {
        const b = document.createElement("button");
        b.type = "button";
        b.textContent = title;
        b.dataset.value = value;
        b.addEventListener("click", () => { onPick(value); refresh(); });
        box.append(b);
    }
    const refresh = () => {
        const now = current();
        for (const b of box.children) b.classList.toggle("netra_on", b.dataset.value === now);
    };
    refresh();
    return { box, refresh };
}

function setInput(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.value = value;
    el.dispatchEvent(new Event("change"));
}

// Netra 설정 › 접속 › 화질과 같은 단계 (NoVNCDefaults: 낮음 2/9 · 보통 6/2 · 높음 9/0)
const QUALITY = { low: [2, 9], normal: [6, 2], high: [9, 0] };

function buildSettings() {
    const panel = document.getElementById("noVNC_settings");
    const list = panel?.querySelector(":scope > ul");
    if (!list) return;
    const li = (id) => document.getElementById(id)?.closest("li");
    const advanced = panel.querySelector(".noVNC_expander + div > ul");

    const fit = seg([["scale", "화면에 맞춤"], ["off", "실제 크기"]],
        () => document.getElementById("noVNC_setting_resize").value,
        (v) => setInput("noVNC_setting_resize", v));
    const quality = seg([["low", "낮음"], ["normal", "보통"], ["high", "높음"]],
        () => {
            const q = +document.getElementById("noVNC_setting_quality").value;
            const c = +document.getElementById("noVNC_setting_compression").value;
            return Object.keys(QUALITY).find(k => QUALITY[k][0] === q && QUALITY[k][1] === c) || "";
        },
        (v) => { setInput("noVNC_setting_quality", QUALITY[v][0]); setInput("noVNC_setting_compression", QUALITY[v][1]); });
    const row = (title, control) => {
        const r = document.createElement("li");
        r.className = "netra_row";
        const s = document.createElement("span");
        s.textContent = title;
        r.append(s, control);
        return r;
    };

    // 위: 자주 쓰는 것 (보기만 · 터치 방식 · 화면 맞춤 · 화질 · 다시 연결 · 커서 점 · 점 크기). 아래 「고급」: 나머지 noVNC 설정 (공유 모드 · 자르기 · 크기 조정 · 화질 세부 · 압축 · Repeater · WebSocket · 간격 · 기록)
    const shared = li("noVNC_setting_shared"), clip = li("noVNC_setting_view_clip"), resize = li("noVNC_setting_resize");
    const dotSeg = seg([["small", "작게"], ["medium", "보통"], ["large", "크게"]], dotSize, setDot);
    const touch = seg([["trackpad", "트랙패드"], ["direct", "직접 누르기"]], touchMode, setTouchMode);
    const top = [li("noVNC_setting_view_only"), row("터치 방식", touch.box), row("화면 맞춤", fit.box), row("화질", quality.box), li("noVNC_setting_reconnect"), li("noVNC_setting_show_dot"), row("점 크기", dotSeg.box)];
    const firstHr = list.querySelector(":scope > li > hr")?.parentElement;
    list.prepend(...top.filter(Boolean));
    if (advanced) {
        advanced.prepend(...[shared, clip, resize].filter(Boolean));
        // 다시 연결 · 커서 점은 위로 옮겼으니, 그 사이 구분선 정리
        for (const hr of advanced.querySelectorAll(":scope > li > hr")) {
            const prev = hr.parentElement.previousElementSibling, next = hr.parentElement.nextElementSibling;
            if (!prev || !next || prev.querySelector("hr") || next.querySelector("hr")) hr.parentElement.remove();
        }
    }
    // 모든 항목을 옮긴 뒤 남은 위쪽 구분선 하나만 둠
    for (const hr of list.querySelectorAll(":scope > li > hr")) if (hr.parentElement !== firstHr) hr.parentElement.remove();
    const ver = panel.querySelector(".noVNC_version_wrapper");
    if (ver) {
        const line = document.createElement("li");
        line.className = "netra_ver";
        line.setAttribute("translate", "no");
        line.textContent = `Netra ${version || ""} · noVNC 1.7.0 (MPL-2.0)`.replace("  ", " ");
        ver.replaceWith(line);
    }
    // 설정을 열 때마다 지금 값으로
    document.getElementById("noVNC_settings_button")?.addEventListener("click", () => { fit.refresh(); quality.refresh(); });
}

// MARK: 마우스 포인터
// 아이폰(터치)에서는 맥이 커서 모양을 보내 줘야 포인터가 보이는데, 맥 화면 공유가 모양을 안 보내거나 투명하게 보내면 아무것도 안 보임.
// noVNC 의 「커서 없을 때 점」(3×3)을 크기를 고를 수 있는 둥근 점으로 바꾸고 기본으로 켬(defaults.json show_dot, NoVNCDefaults)

const DOT_KEY = "netra_dot";
const DOT_SIZES = { small: 9, medium: 15, large: 23 };
function dotSize() { const v = get(DOT_KEY); return v in DOT_SIZES ? v : "medium"; }

// 흰 점 + 검은 테두리 (가운데가 누르는 곳)
function dot(size) {
    const n = DOT_SIZES[size], c = (n - 1) / 2, px = new Uint8Array(n * n * 4);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const d = Math.hypot(x - c, y - c), i = (y * n + x) * 4;
        if (d <= c - 2) px.set([255, 255, 255, 255], i);
        else if (d <= c + 0.3) px.set([0, 0, 0, 255], i);
    }
    return { rgbaPixels: px, w: n, h: n, hotx: Math.floor(c), hoty: Math.floor(c) };
}

function setDot(size) {
    put(DOT_KEY, size);
    RFB.cursors.dot = dot(size);
    if (UI.rfb) UI.rfb._refreshCursor();
}
RFB.cursors.dot = dot(dotSize());

// MARK: 확대해도 메뉴 탭 보이기
// 아이폰 Safari 에서 페이지를 확대하면 position: fixed 인 메뉴 탭(#noVNC_control_bar_anchor)이
// 확대 전 화면(레이아웃 뷰포트)에 붙어 있어 보이는 영역 밖으로 나감.
// visualViewport 를 따라 보이는 영역의 왼쪽(오른쪽) 가장자리로 옮기고 크기는 1/확대배율로 되돌림.
function followZoom() {
    const vv = window.visualViewport;
    const anchor = document.getElementById("noVNC_control_bar_anchor");
    if (!vv || !anchor) return;
    const place = () => {
        if (Math.abs(vv.scale - 1) < 0.01 && Math.abs(vv.offsetLeft) < 1 && Math.abs(vv.offsetTop) < 1) {
            anchor.style.transform = "";
            anchor.style.transformOrigin = "";
            anchor.style.transition = "";
            return;
        }
        const right = anchor.classList.contains("noVNC_right");
        const x = right ? vv.offsetLeft + vv.width - document.documentElement.clientWidth : vv.offsetLeft;
        anchor.style.transition = "opacity 0.5s ease-in-out";
        anchor.style.transformOrigin = right ? "top right" : "top left";
        anchor.style.transform = `translate(${x}px, ${vv.offsetTop}px) scale(${1 / vv.scale})`;
    };
    vv.addEventListener("resize", place);
    vv.addEventListener("scroll", place);
    new MutationObserver(place).observe(anchor, { attributes: true, attributeFilter: ["class"] });
    place();
}

// MARK: 손잡이 어디로나 옮기기
// noVNC 는 왼쪽 막대 손잡이를 막대 높이 안에서만 움직이게 함(app/ui.js moveControlbarHandle).
// 화면 위 끝 ~ 아래 끝까지 옮기게 바꾸고, 자리(화면 높이에 대한 비율)를 그 기기에 기억.
const HANDLE_KEY = "netra_handle";
function freeHandle() {
    const handle = document.getElementById("noVNC_control_bar_handle");
    const bar = document.getElementById("noVNC_control_bar");
    if (!handle || !bar) return;
    const margin = 6;
    UI.moveControlbarHandle = (y) => {
        const h = handle.getBoundingClientRect().height, top = bar.getBoundingClientRect().top;
        if (!h) return;
        const ny = Math.min(Math.max(y, margin), window.innerHeight - h - margin);
        handle.style.transform = `translateY(${ny - top}px)`;
        if (UI.controlbarDrag) put(HANDLE_KEY, String(ny / window.innerHeight));
    };
    const saved = parseFloat(get(HANDLE_KEY));
    if (saved >= 0 && saved <= 1) requestAnimationFrame(() => UI.moveControlbarHandle(saved * window.innerHeight));
}

// MARK: 맥 화면 공유의 보조 키 이름
// noVNC(와 대부분의 VNC)는 ⌘ = Super, ⌥ = Alt 로 보내지만, Apple 화면 공유는 ⌘ = Alt, ⌥ = Meta 로 받음
// (TigerVNC 관리자 Pierre Ossman 확인: https://groups.google.com/g/tigervnc-users/c/rFiYgMCg7r4).
// 그대로 보내면 ⌘V · ⌘Q 가 안 듣고 ⌥ 단추가 ⌘ 로 감 → 원격 화면으로 나가는 곳 한 군데에서 바꿈
// (보조 키 단추 · 붙여넣기 ⌘V · ⌘Q · 하드웨어 키보드 모두 이 길을 지남).
const APPLE_KEYS = {
    [KeyTable.XK_Super_L]: KeyTable.XK_Alt_L, [KeyTable.XK_Super_R]: KeyTable.XK_Alt_R,
    [KeyTable.XK_Alt_L]: KeyTable.XK_Meta_L, [KeyTable.XK_Alt_R]: KeyTable.XK_Meta_R,
};
const plainSendKey = RFB.prototype.sendKey;
RFB.prototype.sendKey = function (keysym, code, down) {
    // 누름 · 뗌을 여기서 나눠야 바꾼 키를 다시 바꾸지 않음
    if (down === undefined) {
        this.sendKey(keysym, code, true);
        this.sendKey(keysym, code, false);
        return;
    }
    return plainSendKey.call(this, APPLE_KEYS[keysym] ?? keysym, code, down);
};

// MARK: 시작

async function info() {
    try {
        const r = await fetch("netra/info.json", { cache: "no-store" });
        if (r.ok) {
            const j = await r.json();
            if (j.name) host = j.name;
            version = j.version || "";
        }
    } catch { /* 기본값: 주소 첫 부분 */ }
}

await info();
if (l10n._dictionary !== undefined) l10n._dictionary = dictionary();
buildLogin();
buildBar();
buildSettings();
fixTitle();
followZoom();
freeHandle();
new MutationObserver(fixTitle).observe(document.querySelector("title"), { childList: true, characterData: true, subtree: true });
new MutationObserver(() => { watchState(); syncLogin(); }).observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
const dlg = document.getElementById("noVNC_connect_dlg");
if (dlg) new MutationObserver(syncLogin).observe(dlg, { attributes: true, attributeFilter: ["class"] });
syncLogin();
