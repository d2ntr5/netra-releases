// Netra: 클립보드 패널의 「맥에 붙여넣기」 · 「맥 클립보드 가져오기」 (design/mockups/clip-zoom.html 3A).
// noVNC 는 VNC 클립보드 메시지(Latin-1)로 보내 한글이 「?」가 되므로, 원격 화면 WebSocket 의 text 프레임으로
// Netra 앱에 보내고 Netra 가 맥 클립보드를 직접 다룸 (Sources/NetraCore/Control.swift). 맥에 로그인한 연결에서만 받음.
// noVNC 1.7.0 의 내부(rfb._sock._websocket · UI.clipboardSend)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";
import KeyTable from "../core/input/keysym.js";

let text, toast;

function socket() {
    const r = UI.rfb;
    const ws = r && r._rfbConnectionState === "connected" ? r._sock?._websocket : null;
    if (!ws) return null;
    if (!ws._netra) {
        // Netra 의 답(text 프레임)은 noVNC 로 넘기지 않음 (noVNC 는 binary 만 읽음)
        const orig = ws.onmessage;
        ws.onmessage = (e) => typeof e.data === "string" ? answer(e.data) : orig.call(ws, e);
        ws._netra = true;
    }
    return ws;
}

function ask(message) {
    const ws = socket();
    if (!ws) { show("연결된 뒤에 쓸 수 있습니다"); return; }
    ws.send(JSON.stringify(message));
}

function answer(data) {
    let m;
    try { m = JSON.parse(data); } catch { return; }
    if (m.netra === "pasted") {
        // 맥 클립보드에 들어갔으니 ⌘V (보조 키 ⌘ 와 같은 키)
        const r = UI.rfb;
        if (r) {
            r.sendKey(KeyTable.XK_Super_L, "MetaLeft", true);
            r.sendKey(KeyTable.XK_v, "KeyV");
            r.sendKey(KeyTable.XK_Super_L, "MetaLeft", false);
        }
        show("맥에 붙여넣었습니다");
    } else if (m.netra === "clipboard") {
        text.value = m.text ?? "";
        show("맥 클립보드를 가져왔습니다");
    } else if (m.netra === "error") {
        show(m.message || "하지 못했습니다", 5000);
    }
}

let toastTimer = null;
function show(message, ms = 2000) {
    toast.textContent = message;
    toast.classList.add("netra_show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("netra_show"), ms);
}

function build() {
    const panel = document.getElementById("noVNC_clipboard");
    text = document.getElementById("noVNC_clipboard_text");
    if (!panel || !text) return;
    // noVNC 의 Latin-1 보내기는 끔 (한글이 「?」로 맥 클립보드를 덮음). 맥 → 아이폰(noVNC 가 받은 글)은 그대로
    text.removeEventListener("change", UI.clipboardSend);
    const row = document.createElement("div");
    row.className = "netra_clip";
    row.innerHTML = `<button type="button" class="netra_pri" data-c="paste">맥에 붙여넣기</button><button type="button" data-c="copy">맥 클립보드 가져오기</button>`;
    row.addEventListener("click", (e) => {
        const k = e.target.closest("button")?.dataset.c;
        if (k === "paste") {
            if (!text.value) { show("칸에 붙여넣을 글을 넣으세요"); return; }
            ask({ netra: "paste", text: text.value });
        } else if (k === "copy") {
            ask({ netra: "copy" });
        }
    });
    const hint = document.createElement("p");
    hint.className = "netra_clip_hint";
    hint.textContent = "「맥에 붙여넣기」: 맥 클립보드에 넣고 ⌘V까지 누름(한글 됨). 「가져오기」: 맥에서 ⌘C 한 글을 이 칸으로.";
    text.after(row, hint);
    toast = document.createElement("div");
    toast.id = "netra_toast";
    document.body.append(toast);
}

build();
