// Netra: 모니터 하나만 골라 보기.
// macOS 화면 공유는 모니터를 모두 이어 붙인 한 화면을 보내므로, noVNC 가 그중 고른 모니터가 있는 곳만 잘라 화면에 맞춰 보여 줌.
// 모니터 배치는 Netra 가 /netra/monitors.json 으로 줌 (포인트, 왼쪽 위 기준). 고른 값은 이 기기 브라우저에만 저장.
// noVNC 1.7.0 의 내부 함수(RFB._updateClip · _updateScale, Display 의 viewport)를 씀 — noVNC 버전을 올리면 다시 확인.
import UI from "../app/ui.js";

const KEY = "netra_monitor";
let monitors = [];
let choice = load();            // 고른 모니터 이름, 없으면 전체
let patched = null;             // 손본 RFB

function load() { try { return localStorage.getItem(KEY); } catch { return null; } }
function save(v) { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch { /* 저장 못 해도 지금은 적용 */ } }

function chosen() { return monitors.find(m => m.name === choice) || null; }

// 모니터 위치(포인트) → 받은 화면(픽셀) 안의 사각형
function region(rfb, m) {
    const d = rfb._display;
    const w = Math.max(...monitors.map(n => n.x + n.width));
    const h = Math.max(...monitors.map(n => n.y + n.height));
    const sx = d.width / w, sy = d.height / h;
    return { x: Math.round(m.x * sx), y: Math.round(m.y * sy), w: Math.round(m.width * sx), h: Math.round(m.height * sy) };
}

function apply(rfb) {
    const m = chosen();
    const d = rfb._display;
    if (!m || !d.width) {
        rfb._netraClip();
        rfb._netraScale();
        return;
    }
    const r = region(rfb, m);
    d.clipViewport = true;
    d.viewportChangeSize(r.w, r.h);
    const vp = d._viewportLoc;
    d.viewportChangePos(r.x - vp.x, r.y - vp.y);
    const size = rfb._screenSize();
    d.autoscale(size.w, size.h);
    d._damage(vp.x, vp.y, vp.w, vp.h);
    d.flip();
    rfb._setClippingViewport(false);
    rfb._fixScrollbars();
}

function patch(rfb) {
    if (!rfb || rfb === patched) return;
    patched = rfb;
    // 창 크기 · 받은 화면 크기가 바뀔 때 noVNC 가 부르는 두 함수를 가로채서, 모니터를 골랐으면 그 모니터만 맞춤
    rfb._netraClip = rfb._updateClip.bind(rfb);
    rfb._netraScale = rfb._updateScale.bind(rfb);
    rfb._updateClip = () => chosen() ? apply(rfb) : rfb._netraClip();
    rfb._updateScale = () => chosen() ? apply(rfb) : rfb._netraScale();
    rfb.addEventListener("connect", () => apply(rfb));
    if (rfb._rfbConnectionState === "connected") apply(rfb);
}

function pick(name) {
    choice = name;
    save(name);
    render();
    if (UI.rfb && UI.rfb === patched) apply(UI.rfb);
    close();
}

// MARK: 화면 (noVNC 제어 막대에 버튼 하나 + 패널)

let button, panel, list;

function build() {
    const settings = document.getElementById("noVNC_settings_button");
    if (!settings) return;
    button = document.createElement("input");
    button.type = "image";
    button.alt = "모니터";
    button.title = "모니터 고르기";
    button.src = "netra/monitor.svg";
    button.id = "netra_monitor_button";
    button.className = "noVNC_button";
    const wrap = document.createElement("div");
    wrap.className = "noVNC_vcenter";
    wrap.innerHTML = `<div id="netra_monitor" class="noVNC_panel">
        <div class="noVNC_heading"><img alt="" src="netra/monitor.svg"> 모니터</div>
        <ul></ul>
        <div class="netra_note">이 기기에 기억됩니다. 고른 모니터를 화면에 맞춰 보여 줍니다.</div>
    </div>`;
    settings.before(button, wrap);
    panel = wrap.querySelector("#netra_monitor");
    list = wrap.querySelector("ul");
    button.addEventListener("click", () => panel.classList.contains("noVNC_open") ? close() : open());
    // noVNC 가 다른 패널을 열 때 이 패널은 닫힘
    const closeAll = UI.closeAllPanels;
    UI.closeAllPanels = () => { closeAll(); close(); };
}

function open() {
    UI.closeAllPanels();
    UI.openControlbar();
    panel.classList.add("noVNC_open");
    button.classList.add("noVNC_selected");
}

function close() {
    panel?.classList.remove("noVNC_open");
    button?.classList.remove("noVNC_selected");
}

function item(name, title, detail) {
    const li = document.createElement("li");
    const b = document.createElement("button");
    b.type = "button";
    b.className = (name || null) === (chosen()?.name ?? null) ? "netra_on" : "";
    b.textContent = title;
    const s = document.createElement("small");
    s.textContent = detail;
    b.append(s);
    b.addEventListener("click", () => pick(name));
    li.append(b);
    return li;
}

function render() {
    if (!button) return;
    // 모니터가 하나면 고를 것이 없음
    button.classList.toggle("noVNC_hidden", monitors.length < 2);
    list.replaceChildren(
        item(null, "전체", "모든 모니터를 한 화면에"),
        ...monitors.map((m, i) => item(m.name, `${i + 1} · ${m.name}`, `${m.width}×${m.height}${m.main ? " · 주 모니터" : ""}`)),
    );
}

async function refresh() {
    try {
        const r = await fetch("netra/monitors.json", { cache: "no-store" });
        monitors = r.ok ? await r.json() : [];
    } catch { monitors = []; }
    render();
    if (UI.rfb && UI.rfb === patched) apply(UI.rfb);
}

build();
refresh();
// 다시 연결하면 noVNC 가 RFB 를 새로 만듦 → 새 것도 손봄. 모니터 배치는 다시 연결할 때 새로 받음
setInterval(() => {
    if (UI.rfb && UI.rfb !== patched) { patch(UI.rfb); refresh(); }
}, 300);
